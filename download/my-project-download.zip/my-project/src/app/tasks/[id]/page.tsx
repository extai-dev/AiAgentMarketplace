'use client';

import { useEffect, useState, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useAccount, useWriteContract, useWaitForTransactionReceipt, useSwitchChain } from 'wagmi';
import { polygonAmoy } from 'wagmi/chains';
import { parseEther, type Address } from 'viem';
import { Navbar } from '@/components/marketplace/Navbar';
import { BidList } from '@/components/marketplace/BidList';
import { BidForm } from '@/components/marketplace/BidForm';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useStore, Task, Bid, TaskStatusType } from '@/store/useStore';
import { useTaskContract, isValidAddress } from '@/hooks/useTaskContract';
import { TASK_ESCROW_ABI } from '@/lib/contracts/TaskEscrow';
import { getAddresses, ERC20_ABI, NEW_ADDRESSES, OLD_ADDRESSES } from '@/lib/contracts/addresses';
import { formatDistanceToNow, format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import {
  ArrowLeft,
  Clock,
  Coins,
  User,
  AlertCircle,
  CheckCircle2,
  Loader2,
  XCircle,
  ExternalLink,
  FileText,
  Copy,
  Check,
  Shield,
  AlertTriangle
} from 'lucide-react';

const statusConfig: Record<TaskStatusType, { label: string; color: string; icon: React.ReactNode }> = {
  OPEN: { label: 'Open for Bids', color: 'bg-blue-500', icon: <Clock className="h-4 w-4" /> },
  IN_PROGRESS: { label: 'In Progress', color: 'bg-yellow-500', icon: <Loader2 className="h-4 w-4" /> },
  COMPLETED: { label: 'Completed', color: 'bg-green-500', icon: <CheckCircle2 className="h-4 w-4" /> },
  DISPUTED: { label: 'Disputed', color: 'bg-red-500', icon: <AlertCircle className="h-4 w-4" /> },
  CLOSED: { label: 'Closed', color: 'bg-gray-500', icon: <CheckCircle2 className="h-4 w-4" /> },
  CANCELLED: { label: 'Cancelled', color: 'bg-gray-400', icon: <XCircle className="h-4 w-4" /> },
};

export default function TaskDetailPage() {
  const params = useParams();
  const router = useRouter();
  const taskId = params.id as string;
  const { address, isConnected, chain } = useAccount();
  const { user } = useStore();
  const { toast } = useToast();
  const { escrowAddress, tokenAddress } = useTaskContract();
  const { writeContract, isPending } = useWriteContract();
  const { switchChainAsync, isPending: isSwitchingChain } = useSwitchChain();
  
  const [task, setTask] = useState<Task | null>(null);
  const [bids, setBids] = useState<Bid[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [txHash, setTxHash] = useState<Address | null>(null);
  const [pendingAction, setPendingAction] = useState<'complete' | 'release' | 'cancel' | null>(null);
  const [pendingData, setPendingData] = useState<{ resultHash?: string } | null>(null);

  // On-chain status tracking
  const [onChainStatus, setOnChainStatus] = useState<{ status: number; statusName: string; hasOnChain: boolean } | null>(null);
  const [isCheckingOnChain, setIsCheckingOnChain] = useState(false);

  // Determine which escrow address to use based on task
  const getTaskEscrowAddress = useCallback(() => {
    if (task?.escrowAddress) {
      return task.escrowAddress;
    }
    if (task?.onChainId !== undefined && task.onChainId !== null) {
      return OLD_ADDRESSES.escrow;
    }
    return escrowAddress;
  }, [task, escrowAddress]);
  const taskEscrowAddress = getTaskEscrowAddress();

  // Check if using gas-optimized contract
  const isOptimizedContract = taskEscrowAddress?.toLowerCase() === NEW_ADDRESSES.escrow.toLowerCase();

  // Check if contracts are deployed
  const hasContracts = isValidAddress(taskEscrowAddress);
  const isCorrectNetwork = chain?.id === 80002; // Polygon Amoy

  // Check if on-chain state matches database
  const onChainStatusMismatch = onChainStatus && task && onChainStatus.hasOnChain
    ? onChainStatus.statusName !== task.status
    : false;

  // Determine if we should use on-chain operations
  const shouldUseOnChain = hasContracts && task?.onChainId && !onChainStatusMismatch;

  // Wait for transaction confirmation
  const { isLoading: isConfirming, isSuccess: isConfirmed } = useWaitForTransactionReceipt({
    hash: txHash,
  });

  // Fetch task and bids
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const taskResponse = await fetch(`/api/tasks/${taskId}`);
        const taskData = await taskResponse.json();
        if (taskData.success) {
          setTask(taskData.data);
          setBids(taskData.data.bids || []);
        } else {
          toast({
            title: 'Error',
            description: 'Task not found',
            variant: 'destructive',
          });
          router.push('/');
        }
      } catch (error) {
        console.error('Failed to fetch task:', error);
        toast({
          title: 'Error',
          description: 'Failed to load task',
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    };

    if (taskId) {
      fetchData();
    }
  }, [taskId, router, toast]);

  // Check on-chain status when task is loaded
  useEffect(() => {
    const checkOnChainStatus = async () => {
      if (task?.onChainId && isValidAddress(taskEscrowAddress)) {
        setIsCheckingOnChain(true);
        try {
          const response = await fetch(`/api/tasks/${task.id}/onchain-status`);
          if (response.ok) {
            const data = await response.json();
            if (data.success) {
              setOnChainStatus(data.data);
            }
          }
        } catch (error) {
          console.error('Failed to check on-chain status:', error);
        } finally {
          setIsCheckingOnChain(false);
        }
      }
    };

    if (task) {
      checkOnChainStatus();
    }
  }, [task, taskEscrowAddress]);

  const refreshTask = async () => {
    try {
      const response = await fetch(`/api/tasks/${taskId}`);
      const data = await response.json();
      if (data.success) {
        setTask(data.data);
        setBids(data.data.bids || []);
      }
    } catch (error) {
      console.error('Failed to refresh task:', error);
    }
  };

  // Handle transaction confirmation - UPDATE DATABASE ONLY AFTER BLOCKCHAIN CONFIRMATION
  useEffect(() => {
    const handleConfirmation = async () => {
      if (isConfirmed && txHash && pendingAction && task) {
        try {
          let updateData: any = { txHash };
          
          if (pendingAction === 'complete' && pendingData?.resultHash) {
            updateData.status = 'COMPLETED';
            updateData.resultHash = pendingData.resultHash;
          } else if (pendingAction === 'release') {
            updateData.status = 'CLOSED';
          } else if (pendingAction === 'cancel') {
            updateData.status = 'CANCELLED';
          }

          // NOW update database after blockchain confirmation
          const response = await fetch(`/api/tasks/${task.id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updateData),
          });

          const result = await response.json();
          if (result.success) {
            const messages = {
              complete: 'Task marked as complete! Waiting for creator approval.',
              release: 'Payment released successfully! Transaction confirmed on blockchain.',
              cancel: 'Task cancelled successfully. Deposit refunded.',
            };
            
            toast({
              title: 'Transaction Confirmed!',
              description: messages[pendingAction],
            });
            refreshTask();
          } else {
            throw new Error(result.error || 'Failed to update database');
          }
        } catch (error: any) {
          console.error('Error updating database:', error);
          toast({
            title: 'Database Update Failed',
            description: 'Blockchain transaction succeeded but database update failed. Please refresh.',
            variant: 'destructive',
          });
        } finally {
          setTxHash(null);
          setPendingAction(null);
          setPendingData(null);
        }
      }
    };

    handleConfirmation();
  }, [isConfirmed, txHash, pendingAction, pendingData, task, toast]);

  const isCreator = address?.toLowerCase() === task?.creator?.walletAddress?.toLowerCase();
  const isAgent = address?.toLowerCase() === task?.agent?.walletAddress?.toLowerCase();

  const handleSwitchNetwork = async () => {
    try {
      await switchChainAsync({ chainId: polygonAmoy.id });
    } catch (error) {
      console.error('Failed to switch network:', error);
    }
  };

  const handleCompleteTask = async () => {
    if (!task || !isAgent || !isCorrectNetwork) return;

    const resultHash = `ipfs://QmResult${Date.now()}`;

    // Use on-chain transaction only if states match
    if (shouldUseOnChain) {
      try {
        const hash = await writeContract({
          address: taskEscrowAddress as Address,
          abi: TASK_ESCROW_ABI,
          functionName: 'completeTask',
          args: [BigInt(task.onChainId!), resultHash],
        });

        setTxHash(hash as Address);
        setPendingAction('complete');
        setPendingData({ resultHash });

        toast({
          title: 'Transaction Submitted',
          description: 'Waiting for blockchain confirmation...',
        });
      } catch (error: any) {
        console.error('Error completing task:', error);
        toast({
          title: 'Transaction Failed',
          description: error.message || 'Please try again.',
          variant: 'destructive',
        });
      }
    } else {
      // Database-only mode (either no onChainId or status mismatch)
      try {
        const response = await fetch(`/api/tasks/${task.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            status: 'COMPLETED',
            resultHash,
          }),
        });

        const result = await response.json();
        if (result.success) {
          toast({
            title: 'Success',
            description: onChainStatusMismatch
              ? 'Task marked complete in database. Note: On-chain state was out of sync - no blockchain transaction needed.'
              : 'Task marked as complete!',
          });
          refreshTask();
        } else {
          throw new Error(result.error || 'Failed to update task');
        }
      } catch (error: any) {
        toast({
          title: 'Error',
          description: error.message,
          variant: 'destructive',
        });
      }
    }
  };

  const handleApproveAndRelease = async () => {
    if (!task || !isCreator || !isCorrectNetwork) return;

    // Use on-chain transaction only if states match
    if (shouldUseOnChain) {
      try {
        const hash = await writeContract({
          address: taskEscrowAddress as Address,
          abi: TASK_ESCROW_ABI,
          functionName: 'approveAndRelease',
          args: [BigInt(task.onChainId!)],
        });

        setTxHash(hash as Address);
        setPendingAction('release');

        toast({
          title: 'Transaction Submitted',
          description: 'Waiting for blockchain confirmation before releasing payment...',
        });
      } catch (error: any) {
        console.error('Error releasing payment:', error);
        toast({
          title: 'Transaction Failed',
          description: error.message || 'Please try again.',
          variant: 'destructive',
        });
      }
    } else {
      // Database-only mode
      try {
        const response = await fetch(`/api/tasks/${task.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: 'CLOSED' }),
        });

        const result = await response.json();
        if (result.success) {
          toast({
            title: 'Success',
            description: 'Payment released successfully! (Database-only mode)',
          });
          refreshTask();
        } else {
          throw new Error(result.error || 'Failed to release payment');
        }
      } catch (error: any) {
        toast({
          title: 'Error',
          description: error.message,
          variant: 'destructive',
        });
      }
    }
  };

  const handleCancelTask = async () => {
    if (!task || !isCreator || !isCorrectNetwork) return;

    // Use on-chain transaction only if states match
    if (shouldUseOnChain) {
      try {
        const hash = await writeContract({
          address: taskEscrowAddress as Address,
          abi: TASK_ESCROW_ABI,
          functionName: 'cancelTask',
          args: [BigInt(task.onChainId!)],
        });

        setTxHash(hash as Address);
        setPendingAction('cancel');

        toast({
          title: 'Transaction Submitted',
          description: 'Waiting for blockchain confirmation before cancelling...',
        });
      } catch (error: any) {
        console.error('Error cancelling task:', error);
        toast({
          title: 'Transaction Failed',
          description: error.message || 'Please try again.',
          variant: 'destructive',
        });
      }
    } else {
      // Database-only mode
      try {
        const response = await fetch(`/api/tasks/${task.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: 'CANCELLED' }),
        });

        const result = await response.json();
        if (result.success) {
          toast({
            title: 'Success',
            description: 'Task cancelled successfully! (Database-only mode)',
          });
          refreshTask();
        } else {
          throw new Error(result.error || 'Failed to cancel task');
        }
      } catch (error: any) {
        toast({
          title: 'Error',
          description: error.message,
          variant: 'destructive',
        });
      }
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container px-4 py-8">
          <div className="space-y-6">
            <Skeleton className="h-8 w-32" />
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-4">
                <Skeleton className="h-12 w-full" />
                <Skeleton className="h-32 w-full" />
                <Skeleton className="h-48 w-full" />
              </div>
              <div className="space-y-4">
                <Skeleton className="h-64 w-full" />
                <Skeleton className="h-64 w-full" />
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (!task) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container px-4 py-8">
          <div className="text-center py-12">
            <AlertCircle className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-xl font-semibold mb-2">Task Not Found</h2>
            <p className="text-muted-foreground">The task you're looking for doesn't exist.</p>
            <Button className="mt-4" onClick={() => router.push('/')}>
              Go Home
            </Button>
          </div>
        </main>
      </div>
    );
  }

  const status = statusConfig[task.status];
  const isLoadingTx = isPending || isConfirming;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container px-4 py-8">
        {/* Back button */}
        <Button variant="ghost" className="mb-6" onClick={() => router.push('/')}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Tasks
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Task Header */}
            <div>
              <div className="flex items-start justify-between gap-4 mb-4">
                <h1 className="text-2xl font-bold">{task.title}</h1>
                <Badge className={status.color}>
                  {status.icon}
                  <span className="ml-1">{status.label}</span>
                </Badge>
              </div>
              
              {/* Task Meta */}
              <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  Created {formatDistanceToNow(new Date(task.createdAt), { addSuffix: true })}
                </div>
                {task.deadline && (
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    Deadline: {format(new Date(task.deadline), 'PPP')}
                  </div>
                )}
                {task.txHash && (
                  <div className="flex items-center gap-1">
                    <ExternalLink className="h-4 w-4" />
                    <a 
                      href={`https://amoy.polygonscan.com/tx/${task.txHash}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:underline"
                    >
                      View Transaction
                    </a>
                  </div>
                )}
              </div>
            </div>

            <Separator />

            {/* Network Warning */}
            {isConnected && !isCorrectNetwork && (
              <div className="bg-orange-50 dark:bg-orange-950 border border-orange-200 dark:border-orange-900 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-orange-600" />
                    <span className="text-orange-800 dark:text-orange-200">
                      Please switch to Polygon Amoy testnet
                    </span>
                  </div>
                  <Button
                    size="sm"
                    onClick={handleSwitchNetwork}
                    disabled={isSwitchingChain}
                  >
                    {isSwitchingChain ? 'Switching...' : 'Switch Network'}
                  </Button>
                </div>
              </div>
            )}

            {/* On-chain Status Mismatch Warning */}
            {onChainStatusMismatch && (
              <div className="bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-900 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-yellow-800 dark:text-yellow-200">
                      On-chain State Mismatch
                    </p>
                    <p className="text-sm text-yellow-700 dark:text-yellow-300 mt-1">
                      The on-chain task status is <strong>"{onChainStatus?.statusName}"</strong> but the database shows <strong>"{task.status}"</strong>.
                      Operations will use database-only mode (no gas fees).
                    </p>
                    <p className="text-xs text-yellow-600 dark:text-yellow-400 mt-2">
                      This happens when tasks were created on-chain but bids/deposits were only saved to the database.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Checking On-chain Status */}
            {isCheckingOnChain && (
              <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-900 rounded-lg p-4">
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin text-blue-600" />
                  <span className="text-blue-800 dark:text-blue-200">
                    Checking on-chain status...
                  </span>
                </div>
              </div>
            )}

            {/* Transaction Status */}
            {isLoadingTx && txHash && (
              <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-900 rounded-lg p-4">
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin text-blue-600" />
                  <span className="text-blue-800 dark:text-blue-200 font-medium">
                    {isConfirming 
                      ? '⏳ Confirming on blockchain... Database will update after confirmation.' 
                      : '📝 Waiting for wallet signature...'}
                  </span>
                </div>
                <a 
                  href={`https://amoy.polygonscan.com/tx/${txHash}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-blue-600 hover:underline flex items-center gap-1 mt-2"
                >
                  View on PolygonScan <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            )}

            {/* Description */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Description</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="whitespace-pre-wrap">{task.description}</p>
              </CardContent>
            </Card>

            {/* Reward Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Reward</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3">
                  <Coins className="h-8 w-8 text-yellow-500" />
                  <div>
                    <p className="text-2xl font-bold">{task.reward} {task.tokenSymbol}</p>
                    <p className="text-sm text-muted-foreground">Token reward for completing this task</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Assigned Agent */}
            {task.agent && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Assigned Agent</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarFallback>
                        {task.agent.name?.[0]?.toUpperCase() || task.agent.walletAddress.slice(1, 3).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{task.agent.name || 'Anonymous Agent'}</p>
                      <p className="text-sm text-muted-foreground font-mono">
                        {task.agent.walletAddress.slice(0, 8)}...{task.agent.walletAddress.slice(-6)}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Result */}
            {task.resultHash && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Task Result</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
                    <FileText className="h-4 w-4 text-muted-foreground" />
                    <code className="text-sm flex-1 truncate">{task.resultHash}</code>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => copyToClipboard(task.resultHash!)}
                    >
                      {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Bids List */}
            <BidList task={task} bids={bids} onBidSubmitted={refreshTask} />

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-3">
              {/* Agent actions */}
              {isAgent && task.status === 'IN_PROGRESS' && (
                <Button
                  onClick={handleCompleteTask}
                  disabled={isLoadingTx || !isCorrectNetwork}
                  className="gap-2"
                >
                  {isLoadingTx ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <CheckCircle2 className="h-4 w-4" />
                  )}
                  Mark Complete
                </Button>
              )}

              {/* Creator actions */}
              {isCreator && task.status === 'COMPLETED' && (
                <Button
                  onClick={handleApproveAndRelease}
                  disabled={isLoadingTx || !isCorrectNetwork}
                  className="gap-2"
                >
                  {isLoadingTx ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Coins className="h-4 w-4" />
                  )}
                  Approve & Release Payment
                </Button>
              )}

              {isCreator && (task.status === 'OPEN' || task.status === 'IN_PROGRESS') && (
                <Button
                  variant="destructive"
                  onClick={handleCancelTask}
                  disabled={isLoadingTx || !isCorrectNetwork}
                  className="gap-2"
                >
                  <XCircle className="h-4 w-4" />
                  Cancel Task
                </Button>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Creator Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Task Creator</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback>
                      {task.creator?.name?.[0]?.toUpperCase() || task.creator?.walletAddress?.slice(1, 3).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{task.creator?.name || 'Anonymous'}</p>
                    <p className="text-sm text-muted-foreground font-mono">
                      {task.creator?.walletAddress?.slice(0, 8)}...{task.creator?.walletAddress?.slice(-6)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Bid Form */}
            {task.status === 'OPEN' && !isCreator && (
              <BidForm task={task} onBidSubmitted={refreshTask} />
            )}

            {/* Contract Status */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Shield className="h-4 w-4" />
                  Blockchain Status
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Network</span>
                  <span className="font-medium">
                    {isCorrectNetwork ? '✓ Polygon Amoy' : chain?.name || 'Not connected'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Mode</span>
                  <span className="font-medium">
                    {hasContracts && task.onChainId ? '✓ On-chain' : 'Database'}
                  </span>
                </div>
                {task.onChainId && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">On-chain ID</span>
                    <span className="font-medium">#{task.onChainId}</span>
                  </div>
                )}
                {hasContracts && (
                  <>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Token</span>
                      <a 
                        href={`https://amoy.polygonscan.com/address/${tokenAddress}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-medium text-blue-600 hover:underline flex items-center gap-1"
                      >
                        View <ExternalLink className="h-3 w-3" />
                      </a>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Escrow</span>
                      <a 
                        href={`https://amoy.polygonscan.com/address/${escrowAddress}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-medium text-blue-600 hover:underline flex items-center gap-1"
                      >
                        View <ExternalLink className="h-3 w-3" />
                      </a>
                    </div>
                  </>
                )}
                <div className="pt-2 border-t text-xs text-muted-foreground">
                  Database updates only after blockchain confirmation
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
