import { NextRequest, NextResponse } from 'next/server';
import { TaskStatus } from '@prisma/client';
import { db } from '@/lib/db';

/**
 * GET /api/tasks
 * Fetch all tasks with optional filtering
 */
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const status = searchParams.get('status') as TaskStatus | null;
    const creatorId = searchParams.get('creatorId');
    const agentId = searchParams.get('agentId');
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = parseInt(searchParams.get('offset') || '0');

    const where: any = {};
    
    if (status) {
      where.status = status;
    }
    if (creatorId) {
      where.creatorId = creatorId;
    }
    if (agentId) {
      where.agentId = agentId;
    }

    const tasks = await db.task.findMany({
      where,
      include: {
        creator: {
          select: {
            id: true,
            walletAddress: true,
            name: true,
          },
        },
        agent: {
          select: {
            id: true,
            walletAddress: true,
            name: true,
          },
        },
        bids: {
          include: {
            agent: {
              select: {
                id: true,
                walletAddress: true,
                name: true,
              },
            },
          },
          orderBy: {
            createdAt: 'desc',
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
      take: limit,
      skip: offset,
    });

    const total = await db.task.count({ where });

    return NextResponse.json({
      success: true,
      data: tasks,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total,
      },
    });
  } catch (error) {
    console.error('Error fetching tasks:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch tasks' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/tasks
 * Create a new task
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      title,
      description,
      reward,
      tokenSymbol = 'TT',
      tokenAddress,
      escrowAddress,
      creatorId,
      deadline,
      onChainId,
      txHash,
    } = body;

    // Validation
    if (!title || !description || !creatorId) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields: title, description, creatorId' },
        { status: 400 }
      );
    }

    if (typeof reward !== 'number' || reward <= 0) {
      return NextResponse.json(
        { success: false, error: 'Reward must be a positive number' },
        { status: 400 }
      );
    }

    // Verify user exists
    const user = await db.user.findUnique({
      where: { id: creatorId },
    });

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    // Create task
    const task = await db.task.create({
      data: {
        title,
        description,
        reward,
        tokenSymbol,
        tokenAddress,
        escrowAddress,
        creatorId,
        onChainId: onChainId || null,
        deadline: deadline ? new Date(deadline) : null,
        txHash,
        status: TaskStatus.OPEN,
      },
      include: {
        creator: {
          select: {
            id: true,
            walletAddress: true,
            name: true,
          },
        },
      },
    });

    return NextResponse.json({
      success: true,
      data: task,
      message: 'Task created successfully',
    }, { status: 201 });
  } catch (error) {
    console.error('Error creating task:', error);
    const errorMessage = error instanceof Error ? error.message : 'Failed to create task';
    const errorStack = error instanceof Error ? error.stack : undefined;
    const errorName = error instanceof Error ? error.constructor.name : 'UnknownError';
    console.log('Full error details:', { errorMessage, errorName, errorStack });
    return NextResponse.json(
      { success: false, error: errorMessage, errorType: errorName },
      { status: 500 }
    );
  }
}
