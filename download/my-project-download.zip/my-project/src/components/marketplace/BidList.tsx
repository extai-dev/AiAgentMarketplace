'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Bid, BidStatusType, Task } from '@/store/useStore';
import { useAccount, useWriteContract, useWaitForTransactionReceipt } from 'wagmi';
import { useTaskContract, isValidAddress } from '@/hooks/useTaskContract';
import { useStore } from '@/store/useStore';
import { useToast } from '@/hooks/use-toast';
import { formatDistanceToNow } from 'date-fns';
import { TASK_ESCROW_ABI } from '@/lib/contracts/TaskEscrow';
import { getAddresses } from '@/lib/contracts/addresses';
import { type Address } from 'viem';
import { 
  Clock, 
  Coins, 
  User, 
  Check, 
  X,
  Loader2,
  MessageSquare,
  ExternalLink
} from 'lucide-react';

interface BidListProps {
  task: Task;
  bids: Bid[];
  onBidAccepted?: () => void;
  onBidSubmitted?: () => void;
}

const statusConfig: Record<BidStatusType, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
  PENDING: { label: 'Pending', variant: 'secondary' },
  ACCEPTED: { label: 'Accepted', variant: 'default' },
  REJECTED: { label: 'Rejected', variant: 'destructive' },
  WITHDRAWN: { label: 'Withdrawn', variant: 'outline' },
};

export function BidList({ task, bids, onBidAccepted, onBidSubmitted }: BidListProps) {
  const { address } = useAccount();
  const { escrowAddress } = useTaskContract();
  const { addNotification } = useStore();
  const { toast } = useToast();
  const { writeContract, isPending } = useWriteContract();
  const [processingBidId, setProcessingBidId] = useState<string | null>(null);
  const [txHash, setTxHash] = useState<Address | null>(null);

  const isCreator = address?.toLowerCase() === task.creator?.walletAddress?.toLowerCase();
  const hasContracts = isValidAddress(escrowAddress);
  const addresses = getAddresses(task.chainId || 80002);

  // Wait for transaction confirmation
  const { isLoading: isConfirming, isSuccess: isConfirmed } = useWaitForTransactionReceipt({
    hash: txHash,
  });

  const handleAcceptBid = async (bid: Bid) => {
    if (!isCreator) return;

    setProcessingBidId(bid.id);
    try {
      // Update bid status in database
      const response = await fetch(`/api/tasks/${task.id}/bids`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bidId: bid.id,
          status: 'ACCEPTED',
        }),
      });

      const result = await response.json();

      if (result.success) {
        toast({
          title: 'Bid accepted!',
          description: 'The agent can now start working on this task.',
        });
        (onBidAccepted || onBidSubmitted)?.();
      } else {
        throw new Error(result.error || 'Failed to accept bid');
      }
    } catch (error: any) {
      console.error('Error accepting bid:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to accept bid',
        variant: 'destructive',
      });
    } finally {
      setProcessingBidId(null);
    }
  };

  const handleRejectBid = async (bid: Bid) => {
    if (!isCreator) return;

    setProcessingBidId(bid.id);
    try {
      const response = await fetch(`/api/tasks/${task.id}/bids`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bidId: bid.id,
          status: 'REJECTED',
        }),
      });

      const result = await response.json();

      if (result.success) {
        toast({
          title: 'Bid rejected',
          description: 'The bid has been rejected.',
        });
        (onBidAccepted || onBidSubmitted)?.();
      } else {
        throw new Error(result.error || 'Failed to reject bid');
      }
    } catch (error: any) {
      console.error('Error rejecting bid:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to reject bid',
        variant: 'destructive',
      });
    } finally {
      setProcessingBidId(null);
    }
  };

  if (bids.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            Bids
          </CardTitle>
          <CardDescription>No bids yet</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No bids have been placed yet.</p>
            <p className="text-sm mt-1">Be the first to bid on this task!</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="h-5 w-5" />
          Bids ({bids.length})
        </CardTitle>
        <CardDescription>
          {isCreator
            ? 'Review and accept bids from agents'
            : 'Bids submitted by agents'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {bids.map((bid) => {
            const status = statusConfig[bid.status];
            const isProcessing = processingBidId === bid.id;

            return (
              <div
                key={bid.id}
                className="border rounded-lg p-4 space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarFallback>
                        {bid.agent?.name?.[0]?.toUpperCase() || bid.agentId.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">
                        {bid.agent?.name || `${bid.agent?.walletAddress?.slice(0, 8)}...`}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {formatDistanceToNow(new Date(bid.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                  <Badge variant={status.variant}>{status.label}</Badge>
                </div>

                <div className="flex items-center gap-4 text-sm">
                  <div className="flex items-center gap-1">
                    <Coins className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{bid.amount} {task.tokenSymbol}</span>
                  </div>
                </div>

                {bid.message && (
                  <p className="text-sm text-muted-foreground bg-muted/50 p-3 rounded">
                    {bid.message}
                  </p>
                )}

                {/* Actions for creator */}
                {isCreator && bid.status === 'PENDING' && task.status === 'OPEN' && (
                  <div className="flex gap-2 pt-2">
                    <Button
                      size="sm"
                      variant="default"
                      className="gap-1"
                      onClick={() => handleAcceptBid(bid)}
                      disabled={isProcessing || isPending || isConfirming}
                    >
                      {isProcessing ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Check className="h-4 w-4" />
                      )}
                      Accept
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="gap-1"
                      onClick={() => handleRejectBid(bid)}
                      disabled={isProcessing || isPending}
                    >
                      <X className="h-4 w-4" />
                      Reject
                    </Button>
                  </div>
                )}

                {/* Transaction status */}
                {txHash && isProcessing && (
                  <div className="text-xs text-muted-foreground">
                    <a 
                      href={`https://amoy.polygonscan.com/tx/${txHash}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 hover:underline"
                    >
                      View transaction <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
