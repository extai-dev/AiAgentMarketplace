'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useAccount, useWriteContract, useWaitForTransactionReceipt, useReadContract, useSwitchChain } from 'wagmi';
import { parseEther, type Address, decodeEventLog } from 'viem';
import { polygonAmoy } from 'wagmi/chains';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useStore } from '@/store/useStore';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { TASK_ESCROW_ABI } from '@/lib/contracts/TaskEscrow';
import { getAddresses, ERC20_ABI } from '@/lib/contracts/addresses';
import { 
  CalendarIcon, 
  Loader2, 
  Coins, 
  FileText,
  AlertCircle,
  CheckCircle2,
  ExternalLink,
  Info
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const taskSchema = z.object({
  title: z.string().min(5, 'Title must be at least 5 characters').max(100, 'Title too long'),
  description: z.string().min(10, 'Description must be at least 10 characters').max(2000, 'Description too long'),
  reward: z.string().min(1, 'Reward is required').refine((val) => !isNaN(parseFloat(val)) && parseFloat(val) > 0, {
    message: 'Reward must be a positive number',
  }),
  deadline: z.date().optional(),
  tokenSymbol: z.string(),
});

type TaskFormData = z.infer<typeof taskSchema>;

interface TaskFormProps {
  onSuccess?: (taskId: string) => void;
}

// Check if address is valid (not zero address)
const isValidAddress = (addr: string | undefined): addr is Address => {
  return !!addr && addr !== '0x0000000000000000000000000000000000000000';
};

export function TaskForm({ onSuccess }: TaskFormProps) {
  const router = useRouter();
  const { address, isConnected, chain } = useAccount();
  const { switchChainAsync, isPending: isSwitchingChain } = useSwitchChain();
  const { user, setUser, addTask } = useStore();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCreatingUser, setIsCreatingUser] = useState(false);
  const [step, setStep] = useState<'form' | 'approving' | 'creating' | 'saving' | 'done'>('form');
  
  // Current transaction hash being waited on
  const [currentTxHash, setCurrentTxHash] = useState<Address | null>(null);
  
  // Store all the data we need in refs to survive re-renders
  const formDataRef = useRef<TaskFormData | null>(null);
  const userIdRef = useRef<string | null>(null);

  const addresses = getAddresses(chain?.id);
  const { writeContractAsync } = useWriteContract();

  // Check if contracts are deployed on current network
  const hasContracts = isValidAddress(addresses?.escrow) && isValidAddress(addresses?.token);
  const isCorrectNetwork = chain?.id === 80002; // Polygon Amoy

  // Read token balance
  const { data: tokenBalance, refetch: refetchBalance } = useReadContract({
    address: addresses?.token as Address,
    abi: ERC20_ABI,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    query: {
      enabled: !!addresses?.token && !!address,
    },
  });

  // Read token allowance
  const { data: tokenAllowance } = useReadContract({
    address: addresses?.token as Address,
    abi: ERC20_ABI,
    functionName: 'allowance',
    args: address && addresses?.escrow ? [address, addresses.escrow as Address] : undefined,
    query: {
      enabled: !!addresses?.token && !!addresses?.escrow && !!address,
    },
  });

  // Wait for current transaction
  const { isLoading: isTxLoading, isSuccess: isTxSuccess, data: txReceipt } = useWaitForTransactionReceipt({
    hash: currentTxHash,
  });

  // Create user when wallet connects
  useEffect(() => {
    const createUser = async () => {
      if (isConnected && address && !user && !isCreatingUser) {
        setIsCreatingUser(true);
        try {
          const response = await fetch('/api/users', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
              walletAddress: address,
              name: 'User',
              role: 'user'
            }),
          });
          const result = await response.json();
          if (result.success) {
            setUser(result.data);
            userIdRef.current = result.data.id;
          }
        } catch (error) {
          console.error('Failed to create user:', error);
        } finally {
          setIsCreatingUser(false);
        }
      } else if (user?.id) {
        userIdRef.current = user.id;
      }
    };
    createUser();
  }, [isConnected, address, user, setUser, isCreatingUser]);

  const form = useForm<TaskFormData>({
    resolver: zodResolver(taskSchema),
    defaultValues: {
      title: '',
      description: '',
      reward: '',
      tokenSymbol: 'TT',
    },
  });

  const rewardValue = form.watch('reward');
  const rewardWei = rewardValue ? parseEther(rewardValue) : BigInt(0);
  const needsApproval = tokenAllowance !== undefined && rewardWei > (tokenAllowance as bigint);

  // Handle transaction confirmation based on current step
  useEffect(() => {
    const handleTxConfirmed = async () => {
      if (!isTxSuccess || !txReceipt || !currentTxHash || !formDataRef.current) {
        console.log('Transaction not ready yet', { isTxSuccess, hasReceipt: !!txReceipt, hasHash: !!currentTxHash, hasFormData: !!formDataRef.current });
        return;
      }

      console.log('Transaction confirmed:', currentTxHash, 'Step:', step);

      if (step === 'approving') {
        // Approval done, now create task
        console.log('Approval confirmed, now creating task...');
        setStep('creating');
        
        try {
          const formData = formDataRef.current;
          const deadlineSeconds = formData.deadline
            ? Math.floor(formData.deadline.getTime() / 1000)
            : Math.floor(Date.now() / 1000) + 7 * 24 * 60 * 60;

          const hash = await writeContractAsync({
            address: addresses!.escrow as Address,
            abi: TASK_ESCROW_ABI,
            functionName: 'createTask',
            args: [
              'Task',
              'See DB',
              parseEther(formData.reward),
              BigInt(deadlineSeconds)
            ],
          });
          
          console.log('Create task tx submitted:', hash);
          setCurrentTxHash(hash as Address);
        } catch (error: any) {
          console.error('Create task error:', error);
          toast({
            title: 'Error creating task',
            description: error.message,
            variant: 'destructive',
          });
          setIsSubmitting(false);
          setStep('form');
          formDataRef.current = null;
        }
      } else if (step === 'creating') {
        // Task created on-chain, now save to database
        console.log('Task created on-chain, parsing task ID...');
        console.log('Transaction receipt logs:', txReceipt.logs.length);
        console.log('Escrow address:', addresses?.escrow);
        
        // Parse task ID from event logs - filter by escrow contract address
        let onChainId: number | null = null;
        const escrowAddr = (addresses?.escrow as Address)?.toLowerCase();
        
        for (const log of txReceipt.logs) {
          // Only process logs from the escrow contract
          if (escrowAddr && log.address.toLowerCase() !== escrowAddr) {
            console.log('Skipping log from different address:', log.address);
            continue;
          }
          
          try {
            const decoded = decodeEventLog({
              abi: TASK_ESCROW_ABI,
              data: log.data,
              topics: log.topics,
            });
            console.log('Decoded log from escrow:', decoded.eventName, decoded.args);
            if (decoded.eventName === 'TaskCreated') {
              onChainId = Number((decoded.args as any).taskId);
              console.log('Found task ID:', onChainId);
              break;
            }
          } catch (e: any) {
            console.log('Could not decode log:', e.message?.substring(0, 100));
          }
        }
        
        if (onChainId === null) {
          console.error('Could not find task ID in logs. Available logs:', txReceipt.logs.length);
          toast({
            title: 'Warning',
            description: 'Task created but could not parse on-chain ID. Task will be database-only.',
            variant: 'destructive',
          });
        }
        
        setStep('saving');
        
        try {
          const formData = formDataRef.current!;
          
          console.log('Saving task to database...', {
            title: formData.title,
            reward: formData.reward,
            onChainId,
            escrowAddress: addresses?.escrow,
            creatorId: userIdRef.current,
            txHash: currentTxHash
          });
          
          const response = await fetch('/api/tasks', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              title: formData.title,
              description: formData.description,
              reward: parseFloat(formData.reward),
              tokenSymbol: formData.tokenSymbol,
              creatorId: userIdRef.current,
              deadline: formData.deadline?.toISOString(),
              onChainId: onChainId,
              escrowAddress: addresses?.escrow,
              txHash: currentTxHash,
            }),
          });

          const result = await response.json();
          console.log('DB response:', result);

          if (!response.ok || !result.success) {
            throw new Error(result.error || `Server error: ${response.status} - ${JSON.stringify(result)}`);
          }
          
          addTask(result.data);
          toast({
            title: 'Task created successfully!',
            description: 'Your task is now live on the blockchain.',
          });
          setStep('done');
          
          // Navigate to task page
          if (onSuccess) {
            onSuccess(result.data.id);
          } else {
            router.push(`/tasks/${result.data.id}`);
          }
        } catch (error: any) {
          console.error('Error saving task:', error);
          toast({
            title: 'Error saving task',
            description: error.message,
            variant: 'destructive',
          });
        } finally {
          setIsSubmitting(false);
          setCurrentTxHash(null);
          formDataRef.current = null;
          setStep('form');
        }
      }
    };

    handleTxConfirmed();
  }, [isTxSuccess, txReceipt, currentTxHash, step, addresses, writeContractAsync, toast, addTask, router, onSuccess]);

  const handleSwitchNetwork = async () => {
    try {
      await switchChainAsync({ chainId: polygonAmoy.id });
    } catch (error) {
      console.error('Failed to switch network:', error);
    }
  };

  // Mint test tokens using backend faucet
  const handleMintTokens = async () => {
    if (!address) return;

    try {
      toast({
        title: 'Getting test tokens...',
        description: 'Please wait while we mint tokens to your wallet.',
      });
      
      const response = await fetch('/api/faucet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ address }),
      });
      
      const result = await response.json();
      
      if (result.success) {
        toast({
          title: 'Tokens minted!',
          description: result.data.message,
        });
        refetchBalance();
      } else {
        throw new Error(result.error || 'Failed to mint tokens');
      }
    } catch (error: any) {
      console.error('Mint error:', error);
      toast({
        title: 'Failed to get tokens',
        description: error.message || 'Please try again.',
        variant: 'destructive',
      });
    }
  };

  const onSubmit = async (data: TaskFormData) => {
    if (!isCorrectNetwork) {
      toast({
        title: 'Wrong Network',
        description: 'Please switch to Polygon Amoy testnet.',
        variant: 'destructive',
      });
      return;
    }

    // Store form data
    formDataRef.current = data;
    setIsSubmitting(true);

    try {
      // Ensure user exists
      if (!userIdRef.current) {
        const guestAddress = address || `0xguest${Date.now().toString(16).padStart(34, '0')}`;
        const userResponse = await fetch('/api/users', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            walletAddress: guestAddress,
            name: isConnected ? 'Connected User' : 'Guest User',
            role: 'user'
          }),
        });
        const userResult = await userResponse.json();
        if (userResult.success) {
          setUser(userResult.data);
          userIdRef.current = userResult.data.id;
        } else {
          throw new Error('Failed to create user profile');
        }
      }

      // Check if user has enough tokens
      const balance = tokenBalance as bigint;
      const reward = parseEther(data.reward);
      
      if (balance && balance < reward) {
        toast({
          title: 'Insufficient Token Balance',
          description: 'Click "Get Test Tokens" to mint TT tokens.',
          variant: 'destructive',
        });
        setIsSubmitting(false);
        formDataRef.current = null;
        return;
      }

      // Step 1: Approve tokens if needed
      if (needsApproval) {
        setStep('approving');
        toast({
          title: 'Step 1/2: Approving Tokens',
          description: 'Please confirm the approval transaction in your wallet.',
        });

        const hash = await writeContractAsync({
          address: addresses!.token as Address,
          abi: ERC20_ABI,
          functionName: 'approve',
          args: [addresses!.escrow as Address, reward],
        });
        
        console.log('Approve tx submitted:', hash);
        setCurrentTxHash(hash as Address);
        return; // Will continue in useEffect when tx confirms
      }

      // Skip to creating if no approval needed
      setStep('creating');
      
      const deadlineSeconds = data.deadline
        ? Math.floor(data.deadline.getTime() / 1000)
        : Math.floor(Date.now() / 1000) + 7 * 24 * 60 * 60;

      const hash = await writeContractAsync({
        address: addresses!.escrow as Address,
        abi: TASK_ESCROW_ABI,
        functionName: 'createTask',
        args: [
          'Task',
          'See DB',
          parseEther(data.reward),
          BigInt(deadlineSeconds)
        ],
      });
      
      console.log('Create task tx submitted:', hash);
      setCurrentTxHash(hash as Address);

    } catch (error: any) {
      console.error('Error creating task:', error);
      toast({
        title: 'Error creating task',
        description: error.message || 'Please try again.',
        variant: 'destructive',
      });
      setIsSubmitting(false);
      setStep('form');
      formDataRef.current = null;
    }
  };

  const tokenBalanceFormatted = tokenBalance 
    ? (Number(tokenBalance as bigint) / 1e18).toFixed(2)
    : '0';

  const isLoading = isSubmitting || isTxLoading;

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Post a New Task
        </CardTitle>
        <CardDescription>
          Create a task for AI agents to complete. 
          {hasContracts 
            ? ' This will create an on-chain task on Polygon Amoy.'
            : ' Connect to Polygon Amoy for blockchain functionality.'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Status Messages */}
            {isConnected ? (
              <Alert className="bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-900">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800 dark:text-green-200">Wallet Connected</AlertTitle>
                <AlertDescription className="text-green-700 dark:text-green-300">
                  {address?.slice(0, 6)}...{address?.slice(-4)}
                  {hasContracts && ` • TT Balance: ${tokenBalanceFormatted}`}
                </AlertDescription>
              </Alert>
            ) : (
              <Alert className="bg-yellow-50 dark:bg-yellow-950 border-yellow-200 dark:border-yellow-900">
                <Info className="h-4 w-4 text-yellow-600" />
                <AlertTitle className="text-yellow-800 dark:text-yellow-200">Connect Wallet</AlertTitle>
                <AlertDescription className="text-yellow-700 dark:text-yellow-300">
                  Connect your wallet to create on-chain tasks.
                </AlertDescription>
              </Alert>
            )}

            {/* Network Warning */}
            {isConnected && !isCorrectNetwork && (
              <Alert className="bg-orange-50 dark:bg-orange-950 border-orange-200 dark:border-orange-900">
                <AlertCircle className="h-4 w-4 text-orange-600" />
                <AlertTitle className="text-orange-800 dark:text-orange-200">Wrong Network</AlertTitle>
                <AlertDescription className="text-orange-700 dark:text-orange-300">
                  <div className="flex items-center justify-between">
                    <span>Please switch to Polygon Amoy testnet.</span>
                    <Button 
                      size="sm" 
                      onClick={handleSwitchNetwork}
                      disabled={isSwitchingChain}
                    >
                      {isSwitchingChain ? 'Switching...' : 'Switch Network'}
                    </Button>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            {/* Low Balance Warning */}
            {isConnected && hasContracts && parseFloat(tokenBalanceFormatted) < 10 && (
              <Alert className="bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-900">
                <Coins className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800 dark:text-blue-200">Get Test Tokens</AlertTitle>
                <AlertDescription className="text-blue-700 dark:text-blue-300">
                  <div className="flex items-center justify-between">
                    <span>You need TT tokens to create tasks.</span>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={handleMintTokens}
                    >
                      Get 1000 TT (Free)
                    </Button>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            {/* Transaction Status */}
            {isLoading && (
              <Alert className="bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-900">
                <Loader2 className="h-4 w-4 animate-spin text-blue-600" />
                <AlertTitle className="text-blue-800 dark:text-blue-200">
                  {step === 'approving' ? 'Approving tokens...' : 
                   step === 'creating' ? 'Creating task on blockchain...' : 
                   step === 'saving' ? 'Saving to database...' : 'Processing...'}
                </AlertTitle>
                {currentTxHash && (
                  <AlertDescription>
                    <a 
                      href={`https://amoy.polygonscan.com/tx/${currentTxHash}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-blue-600 hover:underline flex items-center gap-1"
                    >
                      View on PolygonScan <ExternalLink className="h-3 w-3" />
                    </a>
                  </AlertDescription>
                )}
              </Alert>
            )}

            {/* Step 1: Basic Info */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs">
                  1
                </div>
                Basic Information
              </div>

              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Task Title *</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Analyze customer feedback data" {...field} />
                    </FormControl>
                    <FormDescription>
                      A clear, concise title for your task
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description *</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Describe the task in detail. Include requirements, expected output format, and any relevant context..."
                        className="min-h-[120px]"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Detailed instructions for AI agents
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Step 2: Reward & Deadline */}
            <div className="space-y-4 pt-4 border-t">
              <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs">
                  2
                </div>
                Reward & Timeline
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="reward"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Reward Amount (TT) *</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Coins className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                          <Input
                            type="number"
                            step="0.01"
                            placeholder="10.00"
                            className="pl-10"
                            {...field}
                          />
                        </div>
                      </FormControl>
                      <FormDescription>
                        Your balance: {tokenBalanceFormatted} TT
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="tokenSymbol"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Token</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select token" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="TT">TT (TaskToken)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        Payment token
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="deadline"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Deadline (Optional)</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              'w-full pl-3 text-left font-normal',
                              !field.value && 'text-muted-foreground'
                            )}
                          >
                            {field.value ? (
                              format(field.value, 'PPP')
                            ) : (
                              <span>Pick a deadline</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          disabled={(date) => date < new Date()}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormDescription>
                      Default: 7 days from now
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Submit */}
            <div className="flex justify-end gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => router.push('/')}
                disabled={isLoading}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={isLoading || !isCorrectNetwork} 
                className="min-w-[140px]"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {step === 'approving' ? 'Approving...' : 
                     step === 'creating' ? 'Creating...' : 
                     step === 'saving' ? 'Saving...' : 'Processing...'}
                  </>
                ) : (
                  <>
                    <FileText className="mr-2 h-4 w-4" />
                    Create Task
                  </>
                )}
              </Button>
            </div>

            {/* Info */}
            <div className="text-xs text-muted-foreground text-center space-y-1">
              <p>
                Task creation involves 1-2 transactions depending on token approval status.
                <br />Make sure you have POL for gas and TT tokens for rewards.
              </p>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
